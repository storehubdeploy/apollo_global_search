import pymysql

class DataBase:
    def __init__(self, dbname):
        self.conn = pymysql.connect(host='13.250.125.102', port=3306, db=dbname, user='apollo_user', passwd='apollo_pwd')
        self.cusror = self.conn.cursor()
        self.dbname = dbname

    def fetch(self, condition):
        sql = """
             SELECT '{1}', n.AppId, n.ClusterName , a.`Key`, a.Value FROM Item  as a join Namespace n on a.NamespaceId = n.Id
             WHERE a.`Key` IS NOT NULL AND (a.`Key` LIKE '%{0}%' OR  a.Value LIKE '%{0}%') 
        """.format(condition, self.dbname)
        self.cusror.execute(sql)
        results = [list(x) for x in self.cusror.fetchall()]
        print(results)
        self.cusror.close()
        self.conn.close()
        return results


from flask import Flask, request, render_template, redirect, flash, url_for
from flask_bootstrap import Bootstrap
from db import DataBase

app = Flask(__name__)
bootstrap = Bootstrap(app)

@app.route("/", methods=('GET', 'POST'))
def index():
    if request.method == "POST":
        key = request.form['key']
        if not key:
            flash("input search value must not be null")
            return
        return redirect(url_for('search', keyword=key))
    return render_template('index.html')

@app.route('/search/<string:keyword>', methods=('GET', 'POST'))
def search(keyword):
    if request.method == "GET":
        data = []
        dbnames=['ApolloConfigDB_dev', 'ApolloConfigDB_fat', 'ApolloConfigDB_pro', 'ApolloConfigDB_uat']
        for dbname in dbnames:
            db = DataBase(dbname)
            results = db.fetch(keyword)
            data = data + results
        return render_template('result.html', data=data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80, debug=True)
const { PersonalizeRuntime } = require('@aws-sdk/client-personalize-runtime')
const parse = require('csv-parse/lib/sync')
const fs = require('fs')
const dayjs = require('dayjs')
const utc = require('dayjs/plugin/utc')
dayjs.extend(utc)
const path = require('path')

const consumers = parse(fs.readFileSync('./data/consumer.csv'), {
  columns: true,
  skip_empty_lines: true
})

const stores = parse(fs.readFileSync('./data/store.csv'), {
  columns: true,
  skip_empty_lines: true
})

const actions = parse(fs.readFileSync('./data/action.csv'), {
  columns: true,
  skip_empty_lines: true
})


const cMap = new Map()
const sMap = new Map()

for (const c of consumers) {
  cMap.set(c.PHONE, c)
}

for (const s of stores) {
  sMap.set(s.ITEM_ID, s)
}

module.exports = async (req, res, next) => {
  try {
    console.log('req.query: ', req.query);
    const personalize = new PersonalizeRuntime({
      region: 'ap-southeast-1', credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      }
    })
    const context = {}
    // if (req.query.hour) {
    // context.HOUR = dayjs.utc().hour().toString()
    // }
    // if (req.query.weekday) {
    // context.WEEKDAY = (dayjs.utc().day() + 1).toString()
    // }

    if (req.query.x) {
      context.X = req.query.x
    }

    if (req.query.y) {
      context.Y = req.query.y
    }
    console.log('context: ', context);

    if (req.query.phone) {
      const consumer = cMap.get(req.query.phone)
      const result = await personalize.getRecommendations({
        userId: consumer.USER_ID,
        campaignArn: 'arn:aws:personalize:ap-southeast-1:860545148515:campaign/camp1',
        context
      })

      const response = {
        data: result.itemList.map(item => {
          const s = sMap.get(item.itemId)
          console.log('item.itemId: ', item.itemId);
          if (s) {
            item.weightedRating = s.WEIGHTED_RATING,
              item.rating = s.RATING,
              item.tags = s.GENRE.split('|')
            item.business = s.BUSINESS
            item.rating = s.RATING
            item.weightedRating = s.WEIGHTED_RATING
            item.ratingCount = s.RATING_COUNT
            item.priceLevel = s.PRICE_LEVEL
            item.lat = s.LAT
            item.lng = s.LNG
          }
          return item
        }).sort((a, b) => b.weightedRating - a.weightedRating)
      }
      res.json(response)
    } else {
      res.json({ data: [] })
    }

  } catch (error) {
    next(error)
  }
}

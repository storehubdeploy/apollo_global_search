require('dotenv').config()
const express = require('express')
const app = express()

app.get('/api/get-rec', require('./get-rec'))
app.get('/api/get-user', require('./get-user'))
app.use(express.static('public'))


app.listen(3000)
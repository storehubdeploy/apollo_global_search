const parse = require('csv-parse/lib/sync')
const fs = require('fs')
const dayjs = require('dayjs')
const path = require('path')

const consumers = parse(fs.readFileSync('./data/consumer.csv'), {
  columns: true,
  skip_empty_lines: true
})

const stores = parse(fs.readFileSync('./data/store.csv'), {
  columns: true,
  skip_empty_lines: true
})

const actions = parse(fs.readFileSync('./data/action.csv'), {
  columns: true,
  skip_empty_lines: true
})


const cMap = new Map()
const sMap = new Map()

for (const c of consumers) {
  cMap.set(c.PHONE, c)
}

for (const s of stores) {
  sMap.set(s.ITEM_ID, s)
}




module.exports = async (req, res, next) => {
  try {
    const consumer = cMap.get(req.query.phone)
    console.log('req.query.phone: ', req.query.phone);
    const history = actions.filter(a => a.USER_ID == consumer.USER_ID).map(a => {
      const s = sMap.get(a.ITEM_ID)
      return {
        tags: s.GENRE.split('|'),
        createdTime: dayjs(a.TIMESTAMP * 1000).format('YYYY-MM-DD HH:mm:ss'),
        business: a.BUSINESS
      }
    })
    res.json({
      data: {
        user: consumer,
        actions: history
      }
    })
  } catch (error) {
    res.json(error)
  }
}
